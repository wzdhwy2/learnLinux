.. _vmware_ansible_intro:

**********************************
Introduction to Ansible for VMware
**********************************

Make the case. What does it do?

* Cool thing 1
* Cool thing 2
* Cool thing 3


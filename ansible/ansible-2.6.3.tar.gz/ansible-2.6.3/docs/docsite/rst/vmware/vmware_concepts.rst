.. _vmware_concepts:

***************************
Ansible for VMware Concepts
***************************

Introduction...blah blah

Concept 1
=========

Explanation goes here.

Concept 2
=========

Explanation goes here.
.. _vmware_faq:

******************
Ansible VMware FAQ
******************

vmware_guest
============

Can I deploy a virtual machine on a standalone ESXi server ?
------------------------------------------------------------

Yes. vmware_guest can deploy a virtual machine with required settings on a standalone ESXi server.
